# Android-NFC-P2P-Demo

This is a simple NFC P2P demonstration using Android Beam. You can build any customized application such as an NFC chat application or two-way user authentication using this source code as a base.

Developed by Priyadarshi Gangopadhyay
